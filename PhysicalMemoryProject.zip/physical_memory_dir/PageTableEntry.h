/*
***********************************************************************************
*PROGRAMMER : IBRAHIM KHAN
*DESCRIPTION: THIS PROGRAM IS ABOUT DEMAND PAGE VIRTUAL MEMORY MANAGEMENT
*FILE       : PageTableEntry.h
***********************************************************************************
*/

//HEADER GUARDS
#ifndef PAGETABLEENTRY
#define PAGETABLEENTRY

//USING STANDARD NAMESPACE LIBRARY
using namespace std;

struct PageTableEntry
{
public:
   bool valid;			//BOOL VALUE TO CHECK IF THE ENTRY IS VALID
   int physicalMemoryIndex;	//INDEX FOR PHYSICAL MEMORY
};

#endif
