/*
***********************************************************************************
*PROGRAMMER : IBRAHIM KHAN
*DESCRIPTION: THIS CLASS IS ABOUT MANAGING PHYSICAL MEMORY
*FILE       : PhysicalMemory.h
***********************************************************************************
*/


//HEADER GUARDS
#ifndef PHYSICALMEMORY
#define PHYSICALMEMORY

//PREPROCESSOR DIRECTIVES
#include<iostream>
#include<string>
#include<vector>
#include<cstring>
#include<algorithm>

//USING STANDARD LIBRARY
using namespace std;

class PhysicalMemory
{
public:
        PhysicalMemory(int memorySize, int algorithmIn);	//DEFAULT CONSTRUCTOR
        void access(int frameID);				//TO ACCESS THE FRAME
        void printMemory() const;				//PRINTS THE PHYSICAL MEMORY
        int swapIn(string item);				//GETS THE FRAME ID OF THE SWAPPED IN ITEM
private:
        vector<string>memoryList;				//MEMORY LIST VECTOR ARRAY TO STORE FRAME
        vector<int>timeList;					//VECTOR ARRAY TO MANAGE TIME
        int currentTimeIndex;					//CURRENT TIME
        int algorithmFlag;					//TO INDICATE THE USED ALGORITHM WETHER FIFO OR LRU
        int getNextAvailableFrame();				//CHECKS AND RETURNS INDEX OF THE AVAILABLE FRAMES
        bool isFull();						//CHECKS IF VECTOR ARRAY IS FULL
	int sizeIn;
	int algorithmIndex;

};

/*
***********************************************************************************
*
*METHOD NAME: CONSTRUCTOR
*ARGUMENTS  : NONE
*FUNCTION   : INITIALIZES MEMORY LIST WITH EMPTY STRINGS("") AND TIME LIST WITH 0
*	    : ALSO SETS THE FLAG TO DETERMINE WHICH ALGORITHM IS TO BE USED
*NOTE	    : FIFO WAS USED FOR THIS ASSIGNMENT AND FLAG FOR THAT IS 1.
***********************************************************************************
*/
											//CONSTRUCTOR
PhysicalMemory::PhysicalMemory(int memorySize, int algorithmIn)
{
    currentTimeIndex=0;
    sizeIn = memorySize;
    algorithmIndex = algorithmIn;
    for(int i=0;i < sizeIn;i++)
    {
       memoryList.push_back("");
    }
    for(int i=0;i < sizeIn;i++)
    {
       timeList.push_back(0);
    }
    algorithmFlag=1;
}
/*
***********************************************************************************
*
*METHOD NAME: ACCESS
*ARGUMENTS  : FRAME ID
*FUNCTION   : CHECKS WHICH FRAME FROM MEMORY LIST WAS ACCESSED AND INCREMENTS
*	    : CURRENT TIME INDEX AFTER IT.
***********************************************************************************
*/
											// ACCESS
void PhysicalMemory::access(int frameID)
{
      if(frameID >= 0 && frameID < timeList.size())
	{
         cout << "Physical: Accessed: FrameID: " << frameID << " Contains: " << memoryList.at(frameID) << endl;
	}
   currentTimeIndex++;
}
/*
***********************************************************************************
*
*METHOD NAME: printMemory
*ARGUMENTS  : NONE
*FUNCTION   : PRINTS THE CONTENTS OF THE MEMORY LIST
*
***********************************************************************************
*/
						//PRINT MEMORY
void PhysicalMemory::printMemory() const
{
   for(int i =0;i < memoryList.size();i++)
   {
      cout << " Physical: Memory Spot: " << i << " Contains: " << memoryList.at(i) << endl;
   }
}
/*
***********************************************************************************
*
*METHOD NAME: getNextAvailableFrame
*ARGUMENTS  : NONE
*FUNCTION   : RETURNS THE INDEX OF THE MEMORY LIST ELEMENT WHERE THERE IS AN EMPTY
*	    : SPACE OTHERWISE IF FINDS THE INDEX OF THE LOWEST ELEMENT IN THE
*           : MEMORY LIST ARRAY AND RETURNS THAT
***********************************************************************************
*/
int PhysicalMemory::getNextAvailableFrame()
{
   for(int i = 0; i < memoryList.size(); i++)
   {
      if(memoryList.at(i) == "")
      {
         return i;
      }
   }

   int lowest_element = *min_element(timeList.begin(), timeList.end());		//TO FIND THE LOWEST ELEMENT IN THE MEMORY LIST
   auto temp = find(timeList.begin(), timeList.end(),lowest_element);		//STORES THE LOWEST ELEMENT IN THE TEMP OBJECT
   int lowest_index = 0;
   if(temp!=timeList.end())
   {
      lowest_index = distance(timeList.begin(),temp);		//USING DISTANCE FUNCTION TO FIND THE INDEX OF THE LOWEST ELEMENT IN THE MEMORY LIST
      lowest_index = temp - timeList.begin();
   }
   return lowest_index;
}
/*
*************************************************************************************
*
*METHOD NAME: swapIn
*ARGUMENTS  : A STRING ITEM
*FUNCTION   : THIS METHOD RETURN FRAME ID OF THE ITEM SWAPPED IN THE MEMORYLIST
*	    : ALSO THE CORRESPONDING INDEX OF THE TIME LIST IS UPDATED WITH
*	    : CURRENT TIME INDEX
*************************************************************************************
*/
											//SWAP INDEX
int PhysicalMemory::swapIn(string item)
{
   currentTimeIndex++;					//INCEREMENT CURRENT TIME INDEX
   cout << "Physical: Stored: " << item << endl;		//PRINT STORED ITEM IN THE MEMORY LIST
   int swap_index = getNextAvailableFrame();		//GET THE INDEX OF THE EMPTY OR LOWEST ELEMENT IN THE MEMORY LIST
   memoryList.at(swap_index) = item;			//UPDATE THE ELEMENT TO ITEM AT THE SWAP INDEX IN THE MEMORY LIST
   timeList.at(swap_index) = currentTimeIndex;		//UPDATE TIME LIST TO CURRENT TIME INDEX
   return swap_index;
}
											//IS FULL
/*
*****************************************************************************************
*
*METHOD NAME: isFull
*ARGUMENTS  : NONE
*FUNCTION   : CHECKS IF THE MEMORY LIST IS FULL IF FULL RETURNS TRUE IF NOT RETURNS FALSE
*
*****************************************************************************************
*/

bool PhysicalMemory::isFull()
{

   for(int i = 0; i < memoryList.size()-1; i++)
   {
      if(memoryList.at(i) == "")		//IF AN EMPTY SPACE IS FOUND
      {
         return false;				//RETURN FALSE
      }
   }
return true;					//NO EMPTY SPACES FOUND IN THE MEMORY LIST SO RETURN TRUE(IS FULL)


}
#endif
