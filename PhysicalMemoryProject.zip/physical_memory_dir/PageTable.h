/*
***********************************************************************************
*PROGRAMMER : IBRAHIM KHAN
*DESCRIPTION: THIS CLASS IS ABOUT CREATING PAGE TABLE ENTRIES
*FILE       : PAGETABLE.H
***********************************************************************************
*/

//HEADER GUARDS
#ifndef PAGETABLE
#define PAGETABLE

//PREPROCESSOR DIRECTIVES
#include<iostream>
#include<vector>
#include<string>
#include"PageTableEntry.h"
#include"PhysicalMemory.h"

//STANDARD NAMESPACE LIBRARY
using namespace std;

//PAGETABLE CLASS
class PageTable
{
private:
	vector<PageTableEntry>entryList;
	int numFaults;				//TO COUNT NUMBER OF TOTAL PAGEFAULTS
	PhysicalMemory* mainPhysicalMemory;
        void updateReplacedEntry(int replacedIndex, int pageID);	//UPDATE REPLACEMENT ENTRY
	void pageFault(int pageID, string item);			//PAGE FAULT METHOD
public:
	PageTable(PhysicalMemory* pmIn, int tableSize);			//CONSTRUCTOR
	void reference(int pageID,string item);				//REFERENCE METHOD
	const int getFaults();						//GET FAULTS METHOD
	const void printTable();					//PRINT TABLE METHOD
	void reset();							//RESET TABLE METHOD
};

/*
***********************************************************************************
*METHOD NAME: UpdateReplacedEntry.
*ARGUMENTS  : ReplacedIndex and pageID
*FUNCTION   : THIS METHOD WILL MAKE ORIGINAL MAPPING FOR THE FRAME INVALID
*	      AND UPDATE PAGE TABLE
*
***********************************************************************************
*/

void PageTable::updateReplacedEntry(int replacedIndex, int pageID) 		//UPDATE REPLACEMENT ENTRY IMPLIMENTATION
{
    for(int i=0;i < entryList.size();i++)
    {
	if(entryList.at(i).physicalMemoryIndex == replacedIndex)		//IF PHYSICAL MEMORY INDEX = REPLACED INDEX
	{									//IN USE IF FALSE AND PHYSICAL MEMORY INDEX IS SET TO -1(INVALID)
	   entryList.at(i).valid = false;
	   entryList.at(i).physicalMemoryIndex = -1;
	}
    }
    entryList.at(pageID).valid = true;						//SET NEW MAPPING
    entryList.at(pageID).physicalMemoryIndex = replacedIndex;
}
/*
***********************************************************************************
*METHOD NAME: PageFault.
*ARGUMENTS  : PAGE ID AND PASSED IN ITEM STRING
*FUNCTION   : SWAPS THE ITEM STRING INTO PHYSICAL MEMORY AT AN EMPTY LOCATION
*
***********************************************************************************
*/

void PageTable::pageFault(int pageID, string item)		//PAGE FAULT IMPLIMENTATION
{
cout << "PageTable: page fault occured" << endl;
    numFaults++;
    int S_index = mainPhysicalMemory->swapIn(item);
    updateReplacedEntry(S_index,pageID);
}
/*
************************************************************************************
*METHOD NAME: CONSTRUCTOR
*ARGUMENTS  : NONE
*FUNCTION   : CONSTRUCTOR WILL INITIALIZE ALL VALUES, SET NUMBFAULS, PHYSICAL MEMORY
*	    : AND MAKE THE THE ENTRYLIST VECTOR INVALID TO INITIALIZE IT
************************************************************************************
*/

PageTable::PageTable(PhysicalMemory* pmIn, int tableSize)	//CONSTRUCTOR IMPLIMENTATION
{
   numFaults = 0;
   mainPhysicalMemory = pmIn;
   entryList.resize(tableSize);
   for(int i=0;i < tableSize ;i++)
   {
   entryList.at(i).valid = false;
   entryList.at(i).physicalMemoryIndex = -1;
   }
}
/*
***********************************************************************************
*
*METHOD NAME: Reference
*ARGUMENTS  : PAGE ID AND A STRING ITEM
*FUNCTION   : CHECKS IF ITEM IN MEMORY OR NOT, IF NOT THEN CALLS PAGE FAULT METHOD
*
***********************************************************************************
*/

void PageTable::reference(int pageID,string item)		//REFERENCE IMPLIMENTATION
{
   if(entryList.at(pageID).valid == true)
   {
     mainPhysicalMemory->access(entryList[pageID].physicalMemoryIndex);
   }
   else
   {
     pageFault(pageID, item);
   }
}
/*
***********************************************************************************
*METHOD NAME: PageFault
*ARGUMENTS  : NONE
*FUNCTION   : SWAPS THE ITEM STRING IN PHSYICAL MEMORY
*
***********************************************************************************
*/


const int PageTable::getFaults()		//GET FAULTS IMPLIMENTATION
{
   return numFaults;
}
/*
***********************************************************************************
*METHOD NAME: printTable
*ARGUMENTS  : NONE
*FUNCTION   : THIS METHOD WILL OUTPUT THE CONTENTS OF entryList VECTOR ARRAY
*	    => ASSOCIATED PHYSICAL MEMORY INDEX
*	    => AND THE VALID BOOL FLAG TO DETERMING IF ITS IN USE
***********************************************************************************
*/

const void PageTable::printTable()		//PRINT TABLE IMPLIMENTATION
{
   for(int i = 0; i < entryList.size();i++)
   {
        string use = "";			//STRING TO OUTPUT TRUE OR FALSE AS STRING
        if(entryList.at(i).valid)
	{
	   use = "True";
	}
	else
	{
	use = "False";
	}
        cout << "PageTable: Index: " << i << ": Physical Index: " << entryList.at(i).physicalMemoryIndex << " In Use: " << use  << endl;
   }
   cout << "Page Table:Current total number of pagefaults: " << numFaults << endl;
}
/*
***********************************************************************************
*METHOD NAME: reset
*ARGUMENTS  : NONE
*FUNCTION   : RESETS THE EntryList VECTOR BACK TO INVALID
*
***********************************************************************************
*/

void PageTable::reset()											//RESET IMPLIMENTATION
{
   for(int i = 0; i < entryList.size();i++)
   {
   entryList.at(i).valid = false;
   }
   numFaults = 0;
}

#endif
